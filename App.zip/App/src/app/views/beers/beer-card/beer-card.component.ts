import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BeerModel } from 'src/app/models/beer.model';
import { BeerDialogComponent } from '../beer-dialog/beer-dialog.component';

@Component({
  selector: 'app-beer-card',
  templateUrl: './beer-card.component.html',
  styleUrls: ['./beer-card.component.scss'],
})
export class BeerCardComponent implements OnInit {
  @Input() item!: BeerModel;
  @Output() removeSelected = new EventEmitter<number>();

  constructor(private dialog: MatDialog) {}

  ngOnInit(): void {}

  openDialog(item: BeerModel): void {
    const dialogRef = this.dialog.open(BeerDialogComponent, {
      position: {
        top: '5rem',
      },
      width: '45rem',
      data: item,
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
    });
  }

  onRemove() {
    this.removeSelected.emit(this.item.id);
  }
}
