import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BeerModel } from 'src/app/models/beer.model';
import { BeersService } from 'src/app/services/beers/beers.service';
import { Beer } from 'src/app/shared/common/Beer';

@Component({
  selector: 'app-beer-page',
  templateUrl: './beer-page.component.html',
  styleUrls: ['./beer-page.component.scss'],
})
export class BeerPageComponent implements OnInit {
  beer: BeerModel = new Beer();
  loading: boolean = true;

  constructor(
    private beersService: BeersService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.route.params.subscribe((data: any) => {
      if (data.hasOwnProperty('id') && !isNaN(data.id)) {
        this.beer.id = data.id;
      } else {
        this.router.navigate(['/beers']);
      }
    });
  }

  ngOnInit(): void {
    this.beersService.getBeer(this.beer.id).subscribe(
      (data: BeerModel[]) => {
        //source
        this.beer = data[0];
        this.loading = false;
      },
      (e) => {
        //error handling
        alert(e.message);
        this.router.navigate(['/beers']);
      },
      () => {
        //subscribe complete
      }
    );
  }

  isObject(item: any) {
    return typeof item === 'object';
  }

  extract(item: any) {
    let result = {} as any;
    let literallyObject = Object.assign({}, item);

    const deepExtractObject = (stack: any) => {
      for (let x in stack) {
        if (typeof stack[x] === 'object') {
          deepExtractObject(stack[x]);
        } else {
          result[x] = stack[x];
        }
      }
    };

    deepExtractObject(literallyObject);

    return result;
  }
}
