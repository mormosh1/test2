export enum Cache {
  BeersPagination = 'BeersPagination'
}
