export enum Unit {
  Kilograms = 'kilograms',
  Litres = 'litres',
  Celsius = 'celsius',
  Grams = 'grams',
  None = 'none'
}
