import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './views/widgets/header/header.component';
import { FooterComponent } from './views/widgets/footer/footer.component';
import { BeersComponent } from './views/beers/beers.component';
import { BeerCardComponent } from './views/beers/beer-card/beer-card.component';
import { HttpClientModule } from '@angular/common/http';
import { MaterialsModule } from './shared/materials/materials.module';
import { BeerDialogComponent } from './views/beers/beer-dialog/beer-dialog.component';
import { BeerPageComponent } from './views/beers/beer-page/beer-page.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BeersComponent,
    BeerCardComponent,
    BeerDialogComponent,
    BeerPageComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MaterialsModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
