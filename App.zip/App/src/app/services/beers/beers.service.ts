import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BeerModel } from 'src/app/models/beer.model';
import { CacheBeerPagination } from 'src/app/shared/common/caching/CacheBeerPagination';
import { map } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BeersService extends CacheBeerPagination {
  api = 'https://api.punkapi.com/v2';

  constructor(private http: HttpClient) {
    super();
  }

  getBeers() {
    return this.http.get<BeerModel[]>(`${this.api}/beers`);
  }

  getBeer(id: number) {
    return this.http.get<BeerModel[]>(`${this.api}/beers/${id}`);
  }

  beerPagination(page: number, per_page: number) {
    const call = this.http.get<BeerModel[]>(
      `${this.api}/beers?page=${page}&per_page=${per_page}`
    );
    const data = this.getPaginationDataByPage(page);
    if (data) {
      return of(data);
    } else {
      return call.pipe(
        map((data: BeerModel[]) => {
          this.setPaginationData(data, page);
          return data;
        })
      );
    }
  }

  findBeersByFoodPairing(food_pairing: string) {
    return this.http.get<BeerModel[]>(`${this.api}/beers?food=${food_pairing}`);
  }
}
