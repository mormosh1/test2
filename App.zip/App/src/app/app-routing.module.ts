import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BeerPageComponent } from './views/beers/beer-page/beer-page.component';
import { BeersComponent } from './views/beers/beers.component';

const routes: Routes = [
  { path: '', redirectTo: '/beers', pathMatch: 'full' },
  {
    path: 'beers',
    component: BeersComponent,
  },
  {
    path: 'beers/:id',
    component: BeerPageComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
