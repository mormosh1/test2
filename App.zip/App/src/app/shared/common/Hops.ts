import { HopsModel, VolumeModel } from 'src/app/models/beer.model';
import { Volume } from './Volume';

export class Hops implements HopsModel {
  name: string;
  amount: VolumeModel;
  add: string;
  attribute: string;

  constructor() {
    this.name = '';
    this.amount = new Volume();
    this.add = '';
    this.attribute = '';
  }
}
