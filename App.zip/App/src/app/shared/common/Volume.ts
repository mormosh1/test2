import { Unit } from "src/app/enums/Unit.enum";
import { VolumeModel } from "src/app/models/beer.model";

export class Volume implements VolumeModel{
  value: number;
  unit: Unit.Celsius | Unit.Litres | Unit.Grams | Unit.Grams | Unit.None;
  constructor(){
    this.value = 0;
    this.unit = Unit.None;
  }
}
