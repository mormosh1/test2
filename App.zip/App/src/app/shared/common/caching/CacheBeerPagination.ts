import { Cache } from 'src/app/enums/Cache.enums';
import { BeerModel } from 'src/app/models/beer.model';
import { Beer } from '../Beer';
import { CacheBase } from './CacheBase';

export class CacheBeerPagination extends CacheBase {
  constructor() {
    super(Cache.BeersPagination);
  }

  setPaginationData(data: Beer[], page: number): void {
    const result = this.getPresetData() as any;
    let schema = result ? result : {};
    schema[page] = data;
    this.setPresetData(schema);
  }

  getPaginationDataByPage(page: number): BeerModel[] | null {
    const result = this.getPresetData() as any;
    if (result && result.hasOwnProperty(page) && result[page].length > 0) {
      return result[page];
    } else {
      return null;
    }
  }

  getPreset(): number {
    let pageIndex: any = localStorage.getItem('pageIndex');
    if (pageIndex && !isNaN(pageIndex)) {
      return parseInt(pageIndex);
    } else {
      localStorage.setItem('pageIndex', '1');
      return 1;
    }
  }

  setPreset(pageIndex: number): void {
    localStorage.setItem('pageIndex', pageIndex.toString());
  }

  removeItem() {}
}
