import { Cache } from 'src/app/enums/Cache.enums';

export class CacheBase {
  private presetName: Cache;

  constructor(presetName: Cache) {
    this.presetName = presetName;
  }

  setPresetData(data: object) {
    localStorage.setItem(this.presetName, JSON.stringify(data));
  }

  getPresetData(): Object | null {
    let result = localStorage.getItem(this.presetName);
    if (result) {
      result = JSON.parse(result);
      if (this.isValid(result)) return result;
    }
    return null;
  }

  isValid(result: any) {
    return (
      result !== null &&
      typeof result === 'object' &&
      Object.keys(result).length !== 0
    );
  }

  removePresetData() {
    localStorage.removeItem(this.presetName);
  }
}
