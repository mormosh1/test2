import { PageEvent } from '@angular/material/paginator';
import { CacheBeerPagination } from './caching/CacheBeerPagination';

export class Pager extends CacheBeerPagination {
  length: number;
  pageSize: number;
  lowValue: number;
  highValue: number;
  pageSizeOptions: Array<number>;
  pageIndex: number;

  constructor() {
    super();
    this.length = 3600;
    this.pageSize = 12;
    this.lowValue = 0;
    this.highValue = 12;
    this.pageSizeOptions = [6, 12];
    this.pageIndex = this.getPreset();
  }

  indexLogic(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.setPreset(this.pageIndex);
  }
}
