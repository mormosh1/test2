import { TempModel, VolumeModel } from 'src/app/models/beer.model';
import { Volume } from './Volume';

export class Temp implements TempModel{
  temp: VolumeModel;
  duration?: number;
  constructor() {
    this.temp = new Volume();
  }
}
